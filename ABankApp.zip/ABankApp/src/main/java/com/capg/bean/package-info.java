/**
 * 
 */
/**
 * @author learning
 *
 */
package com.capg.bean;