package com.capg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import com.capg.bean.AccountDetails;
import com.capg.util.DButil;

public class BankDAO implements IBankDAO
{
  static Connection connect;
  static ResultSet tempResult;
 static long tid;
 static AccountDetails accDetails=new AccountDetails();
  
  public boolean addCustomer(AccountDetails accDetails) 
  {
	  int x=0;
	  int y=0;
	  
	 try {
	  
	  try {
			connect=DButil.getConnection();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	  String insertCustomer="insert into customerdetails values(?,?,?,?,?,?)";
	  
	  java.sql.PreparedStatement pstmtC;
	  
	  pstmtC = connect.prepareStatement(insertCustomer);
	
	  pstmtC.setString(1, accDetails.getCustDetails().getCustomerName());
	  pstmtC.setString(2, accDetails.getCustDetails().getEmailId());
	  pstmtC.setString(3, accDetails.getCustDetails().getPhoneNumber());
	  pstmtC.setString(4, accDetails.getCustDetails().getUsername());
	  pstmtC.setString(5, accDetails.getCustDetails().getPassword());
	  pstmtC.setLong(6, accDetails.getCustomerTid());
	 
	  tid=accDetails.getCustomerTid();    //assigning the customer tid to tid variable;
	  
	  String insertAcc="insert into accountdetails values(?,?)";
	  
	  java.sql.PreparedStatement pstmtA = connect.prepareStatement(insertAcc);
	  
	 
	  pstmtA.setLong(1, accDetails.getCustomerTid());
	  pstmtA.setFloat(2, accDetails.getInitialBal());
	  
	
	 
	   x=pstmtC.executeUpdate();
		 
	   y=pstmtA.executeUpdate();
	
	 
	  } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
     }finally {
    	 try {
			connect.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
     }
	 
	 if(x==1 && y==1)
	 {
		return true; 
	 }
	  return false;
  }
  
  public boolean uselogin(String uname,String pass)
  {
	  int x=0;
	  try 
	  {
	 connect=DButil.getConnection();
	 
          String loginA="select * from customerdetails where username='"+uname+"'and password='"+pass+"'";  //check once ??
		  
		  PreparedStatement stmtL=connect.prepareStatement(loginA);
		  
		  ResultSet resultLogin=stmtL.executeQuery(loginA);  //ResultSet contains the rows that satisfy the conditions of the query
		  tempResult=resultLogin;
		  tid=accDetails.getCustomerTid(); 
		  
		  while(resultLogin.first())
		  {
			  tid=resultLogin.getLong("customerTid");
			  return true;
		  } 
	     }catch (ClassNotFoundException e) {
			
			e.printStackTrace();
         }catch (SQLException e) {
		
		e.printStackTrace();
        }
	  return false;
		  
	}
	  
		
 public float showBalance() 
 {
	  try {
			
			
			String display = "select * from accountdetails WHERE customerTid=?";
			
			PreparedStatement pstmtS = connect.prepareStatement(display);
			
			pstmtS.setLong(1,tid);
			
			ResultSet rsshow = pstmtS.executeQuery(); //ResultSet contains the rows that satisfy the conditions of the query

			while (rsshow.next()) 
			{
				
				System.out.println(rsshow.getFloat("initialBal"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	return  0;
	
		
		
		
 }  	

public boolean deposit(float amount)   
{
	try {
		
		String deposit = "Update accountdetails SET initialBal =initialBal+? WHERE  customerTid=?";
		
		PreparedStatement pstmtD = connect.prepareStatement(deposit);
		pstmtD.setFloat(1, amount);
		pstmtD.setLong(2,tid);
	
		int flag = pstmtD.executeUpdate();
		
		if (flag == 1) 
		{
			
		String s1 = "money Deposited "+Float.toString(amount);
		String trans = "insert into transaction values('" +tid+ "','" +s1+ "') ";
		PreparedStatement pstmtT= connect.prepareStatement(trans);
		pstmtT.executeUpdate();
		return true;
		
		}
		
	} catch (Exception e) {

		e.printStackTrace();
	}
	return true;

}

  public boolean withdraw(float amount1)
  {
 
	try {
		
		
		 String withdraw = "update accountdetails SET initialBal =initialBal-? WHERE customerTid=?";
		  PreparedStatement pstmtW = connect.prepareStatement(withdraw);
		
		  pstmtW.setFloat(1,amount1);
		  pstmtW.setLong(2,tid);
		
		int flag = pstmtW.executeUpdate();
		if (flag == 1) 
		{
			
			String s1 = "Amount "+Float.toString(amount1)+" was Withdrawn" ;
			String trans = "insert into transaction values('" +tid + "','" + s1 + "') ";
			PreparedStatement pstmtT = connect.prepareStatement(trans);
			pstmtT.executeUpdate();
            
			return true;
		}

	} catch (Exception e) {
		e.printStackTrace();
	}
	return true;
}

  public boolean fundTransfer(int custAccNum, float amount) 
  {
	 try
	 {
		
		connect = DButil.getConnection();

		String query = "update accountdetails SET initialBal = initialBal-? where customerTid=?";
		PreparedStatement pstmt = connect.prepareStatement(query);
		pstmt.setFloat(1,amount);
		pstmt.setLong(2, tid);
		pstmt.executeUpdate();

		String query1 = "update accountdetails SET initialBal = initialBal+? where customerTid=?";
		PreparedStatement pstmt1 = connect.prepareStatement(query1);
		pstmt1.setFloat(1,amount);
		pstmt1.setInt(2,custAccNum);
		pstmt1.executeUpdate();
		
		
		String s1 = "Fund got Transferred ";
		String trans = "insert into transaction values('" +tid+ "','" + s1 + "') ";
		PreparedStatement pstmtT = connect.prepareStatement(trans);
		pstmtT.executeUpdate();

		
	  }catch (Exception e) {
		e.printStackTrace();
	  }

	return true;

 }

    public void printTransaction() {
	try {
		
		connect = DButil.getConnection();
		 
		String trans = "select * from transaction WHERE customerTid=?";
		
		PreparedStatement pstmtT = connect.prepareStatement(trans);
		
		pstmtT.setLong(1,tid);
		
		ResultSet resultLogin = pstmtT.executeQuery();
		
		while (resultLogin.next()) 
		{
			System.out.println(resultLogin.getString(2));  //transaction info
		}

	} catch (Exception e) {
		e.printStackTrace();
	}
	try {
		connect.close();
	} catch (Exception e) {
		e.printStackTrace();
	}

}

	public boolean useLogin(String uname, String pass) {
		// TODO Auto-generated method stub
		return false;
	}

}	 
	 
	 

